// C program to implement Depth-First Search (DSF) algorithm
 
#include <stdio.h>
#include <stdlib.h>
 
#define MAX 100
 
// function to perform DSF traversal
void DSF(int adj[][MAX], int visited[], int start, int n)
{
    int stack[MAX], top = -1, i;
 
    // push the start vertex into the stack
    stack[++top] = start;
 
    while (top >= 0) {
        // pop the top vertex from the stack
        start = stack[top--];
 
        // check if the vertex is visited or not
        if (!visited[start]) {
            printf("%d ", start);
            visited[start] = 1;
        }
 
        // push the adjacent vertices of the popped vertex into the stack
        for (i = n - 1; i >= 0; i--) {
            if (adj[start][i] && !visited[i]) {
                stack[++top] = i;
            }
        }
    }
}
 
int main()
{
    int adj[MAX][MAX], visited[MAX] = { 0 };
    int i, j, n;
 
    printf("Enter the number of vertices: ");
    scanf("%d", &n);
 
    printf("Enter the adjacency matrix: \n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &adj[i][j]);
        }
    }
 
    printf("DSF traversal starting from vertex 0: ");
    DSF(adj, visited, 0, n);
 
    return 0;
}


// #include<stdio.h>

// #include<stdbool.h>

// #define MAX_NODES 100

// int graph[MAX_NODES][MAX_NODES];
// bool visited[MAX_NODES];

// void DSF(int currentNode ,int numNodes){
//     printf("%d ",currentNode);
//     visited[currentNode]=true;


//     for(int i=0;i<numNodes;i++){
//         if(graph[currentNode][i]==1&&!visited[i]){
//             DSF(i,numNodes);
//         }
//     }
// }

// int main(){

// int numNodes,numEdges;
// printf("Enter the number of nodes and Edges: ");
// scanf("%d %d",&numNodes,&numEdges);

// for (int i = 0; i < numNodes; i++)
// {
//     visited[i]=false;
//     for (int j = 0; j < numNodes; j++)
//     {
//        graph[i][j]=0;
//     }
    
// }

// // build  agraph

// printf("Enter the edges (node1 and node2):\n");
// for(int i=0;i<numEdges;i++){
//     int node1,node2;
//     scanf("%d %d",&node1,&node2);
//     graph[node1][node2]=1;
//     graph[node2][node1]=1;
// }

// int startNode;
// printf("Enter the Start Node : \n");
// scanf("%d",&startNode);

// printf("Dfs traversal : ");
// DSF(startNode,numNodes);



//     return 0;
// }