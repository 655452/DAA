#include<stdio.h>

#define VI 24

void BellMan(int v,int mat[v][v]){


for (int k = 0; k < v; k++)
{
    for (int i = 0; i < v; i++)
{
    for (int j = 0; j < v; j++)
    {
        if(mat[i][j]>mat[i][k]+mat[k][j]){
            mat[i][j]=mat[i][k]+mat[k][j];
        }
    }
   
}
}

print(mat,v);
}


void print(int v,int mat[v][v]){


    for (int i = 0; i < v; i++)
{
    for (int j = 0; j < v; j++)
    {
        printf("%d ",mat[i][j]);
    }
    printf("\n");
}

}

int main(){

int V;
printf("Enter the vertices : ");
scanf("%d",&V);

printf("Enter the matrix : ");
int arr[V][V];
for (int i = 0; i < V; i++)
{
    for (int j = 0; j < V; j++)
    {
        int temp;
        scanf("%d",&temp);
        arr[i][j]=temp;
    }
    
}

// print(V,arr);
BellMan(V,arr);


    return 0;
}