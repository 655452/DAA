#include<stdio.h>

void merge(int arr[],int l,int m,int r){


    int n1=m-l+1;
    int n2=r-m;

    int L[n1],R[n2];

    for (int i = 0; i < n1; i++)
    {
        L[i]=arr[l+i];
    }
    for (int i = 0; i < n2; i++)
    {
       R[i]=arr[m+1+i];
    }
    
    int i=0,j=0,k=l;

    while (i<n1&&j<n2)
    {
        if(L[i]<R[j])
        {
            arr[k]=L[i];
            i++;
        }
        else{
            arr[k]=R[j];
            j++;
        }
        k++;
        /* code */
    }
    
    while (i<n1)
    {
        arr[k]=L[i];
        i++;
        k++;

    }

    while (j<n2)
    {
        arr[k]=R[j];
        j++;
        k++;
        /* code */
    }
    
    
    

}

void merSort(int arr[],int l, int r)
{
    if(l<r){
  int mid=(l+r)/2;

    merSort(arr,l,mid);
    merSort(arr,mid+1,r);

    merge(arr,l,mid,r);
}

}
void print(int arr[],int len){

    for (int i = 0; i < len; i++)
    {
        printf("%d -> ",arr[i]);
    }
    printf("\n");
    
}
int main()
{
int arr[6]={10,2,345,47,12,15};

    merSort(arr,0,6);
    print(arr,6);
    return 0;
}