#include<stdio.h>

void linearSearch(int arr[],int len,int num){
    int count=0;
    for(int i=0;i<len;i++){
           if(num==arr[i]){
            printf("Found at index %d ",i+1);
            count++;
           }
    }
if(count==1){
    printf("");
}
else{
    printf("Element not found");
}

}
void recLin(int arr[],int len,int num){
    int i=len;
    if(arr[len]==num){
            printf("Found at index %d ",len+1);
    }
    else{
        recLin(arr,len-1,num);
    }
}


int Bin(int arr[],int l,int r,int x){
// int mid=(l+(r-1))/2;
while (l <= r) {
        int m = l + (r - l) / 2;
 
        // Check if x is present at mid
        if (arr[m] == x)
            return m;
 
        // If x greater, ignore left half
        if (arr[m] < x)
            l = m + 1;
 
        // If x is smaller, ignore right half
        else
            r = m - 1;
    }
    return -1;
}
int main(){

    int arr[5]={10,42,20,2,3};
int num;
printf("Enter the Number to search \n");
scanf("%d",&num);
// linearSearch(arr,5,num);

// recLin(arr,5,num);

//  now binary sorted array
 int arr2[5]={10,25,35,47,56};

int z=Bin(arr2,0,5,num);
printf("Fount at index %d ",z);


    return 0;
}