#include<stdio.h>
#define MAX 100

void dfs(int arr[4][4],int start,int visited[],int n){

    int stack[MAX],top=-1;
    stack[++top]=start;

    while (top>=0)
    {
        start=stack[top--];

        if(!visited[start]){
            printf("%d ",start);
            visited[start]=1;
        }

        for (int i =n-1 ; i >= 0; i--)
        {
            if(arr[start][i]&&!visited[i]){
               stack[++top]=i;
            }
        }
        


    }
    
}

void bfs(int arr2[4][4],int start,int visited[],int n){
    int queue[MAX],rear=-1,front=-1;
    queue[++rear]=start;
   
 visited[start]=1;
    while (front!=rear)
    {
       start= queue[++front];
       printf("%d ->",start);
       

        for (int i = 0; i < n; i++)
        {
            if(arr2[start][i]&&!visited[i]){
                queue[++rear]=i;
                visited[i]=1;
            }
        }
        
          
        
    }
    
}

int main()
{

    int arr[4][4]={
        {0,1,0,1},
        {0,0,1,0},
        {1,1,0,0},
        {1,0,1,0}
    };
    int arr2[4][4]={
        {1,1,0,1},
        {0,0,1,0},
        {1,0,0,0},
        {1,0,1,0}
    };

    int visited[MAX]={0};

// printf("\n Bfs tRaversal \n");
//     bfs(arr2,0,visited,4);
printf("Dfs tRaversal \n");
    dfs(arr,0,visited,4);


    return 0;
}