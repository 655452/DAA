#include<stdio.h>
#define MAX_NODES 100
#define INF 999999

// graph using adjacency matrix
int graph[MAX_NODES][MAX_NODES];


void floydWarshall(int numNodes){
    int dist[MAX_NODES][MAX_NODES];
    

    // intilize the distance matrix
    for (int i = 0; i < numNodes; i++)
    {
        for (int j = 0;j < numNodes; j++)
        {
            if(graph[i][j]!=0){
                dist[i][j]=graph[i][j];
            }
            else{
                dist[i][j]=INF;
            }
        }
        
    }

    // update the distance amtrix
    for (int k = 0; k < numNodes; k++)
    {
        for (int i = 0; i < numNodes; i++)
        {
            for (int j = 0; j < numNodes; j++)
            {
               if(dist[i][k]+dist[k][j]<dist[i][j]){
                dist[i][j]=dist[i][k]+dist[k][j];
               }
            }
            
        }
        
    }
    
    // print the Shortest distance between all pairs of  vertices
    printf("Shortest distance between  all apirs  of vertices \n");
    for(int i=0;i<numNodes;i++)    
    {
        for (int j = 0; j < numNodes; j++)
        {
            if(dist[i][j]==INF){
                printf("INF \t");
            }
            else{
                printf("%d \t",dist[i][j]);
            }
        }
        printf("\n");
    }
}

int main(){
    int n=3;
    int adj[n][n];
    printf("Enter the matrix\n");

    for (int i = 0; i < n-1; i++)
    {
        for(int j=0;j<n;j++){
            scanf("%d ",&adj[i][j]);

        }
        
    }
    for (int i = 0; i < n; i++)
    {
        for(int j=0;j<n;j++){
            printf("%d ",adj[i][j]);

        }
        printf("\n");
    }
    

    

    return 0;

}