#include <stdio.h>
#include <stdlib.h>

#define MAX 10 // Maximum number of cities

int cost[MAX][MAX]; // Cost matrix
int visited[MAX];   // Visited array to keep track of visited cities
int numCities;      // Number of cities

int minCost = 999;         // Variable to store the minimum cost
int optimalPath[MAX];      // Array to store the optimal path

// Function to calculate the cost of the path
int calculateCost(int path[]) {
    int i, totalCost = 0;
    for (i = 0; i < numCities - 1; i++) {
        totalCost += cost[path[i]][path[i + 1]];
    }
    totalCost += cost[path[numCities - 1]][path[0]]; // Return to the starting city
    return totalCost;
}

// Function to generate all possible permutations of cities
void permute(int path[], int depth) {
    int i, temp;
    if (depth == numCities - 1) {
        int currentCost = calculateCost(path);
        if (currentCost < minCost) {
            minCost = currentCost;
            for (i = 0; i < numCities; i++) {
                optimalPath[i] = path[i];
            }
        }
    } else {
        for (i = depth; i < numCities; i++) {
            // Swap cities
            temp = path[depth];
            path[depth] = path[i];
            path[i] = temp;

            // Recursive call
            permute(path, depth + 1);

            // Swap back to restore the original path
            temp = path[depth];
            path[depth] = path[i];
            path[i] = temp;
        }
    }
}

int main() {
    int i, j;

    printf("Enter the number of cities: ");
    scanf("%d", &numCities);

    printf("Enter the cost matrix:\n");
    for (i = 0; i < numCities; i++) {
        for (j = 0; j < numCities; j++) {
            scanf("%d", &cost[i][j]);
        }
    }

    int path[MAX];
    for (i = 0; i < numCities; i++) {
        path[i] = i;
        visited[i] = 0;
    }

    permute(path, 0);

    printf("\nThe optimal path is: ");
    for (i = 0; i < numCities; i++) {
        printf("%d ", optimalPath[i]);
    }
    printf("%d", optimalPath[0]); // Return to the starting city

    printf("\nMinimum cost: %d\n", minCost);

    return 0;
}
