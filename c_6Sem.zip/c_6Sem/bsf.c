// C program to implement Breadth-First Search (BSF) algorithm
 
#include <stdio.h>
#include <stdlib.h>
 
#define MAX 100
 
// function to perform BSF traversal
void BSF(int adj[][MAX], int visited[], int start, int n)
{
    int queue[MAX], front = -1, rear = -1, i;
 
    // enqueue the start vertex into the queue
    queue[++rear] = start;
    visited[start] = 1;
 
    while (front != rear) {
        // dequeue the front vertex from the queue
        start = queue[++front];
        printf("%d ", start);
 
        // enqueue the adjacent vertices of the dequeued vertex into the queue
        for (i = 0; i < n; i++) {
            if (adj[start][i] && !visited[i]) {
                queue[++rear] = i;
                visited[i] = 1;
            }S
        }
    }
}
 
int main()
{
    int adj[MAX][MAX], visited[MAX] = { 0 };
    int i, j, n;
 
    printf("Enter the number of vertices: ");
    scanf("%d", &n);
 
    printf("Enter the adjacency matrix: \n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &adj[i][j]);
        }
    }
 
 int num;
 printf("Enter the starting vertex");
 scanf("%d",&num);
    printf("BSF traversal starting from vertex 0: ");
    BSF(adj, visited, num, n);
 
    return 0;
}
