#include<stdio.h>
#define MAX 10

int cost[MAX][MAX];
int visited[MAX];
int numCities=4;

int minCost=999;
int optimalPath[MAX];

int calculateCost(int path[]){
    int totalCost=0;
    for (int i = 0; i < numCities-1; i++)
    {
        totalCost+=cost[path[i]][path[i+1]];
    }
     totalCost+=cost[path[numCities-1]][path[0]];
     return totalCost;
}

void permute(int path[],int depth){
int temp;
    if(depth==numCities-1){
        int currentCost=calculateCost(path);
        if(currentCost<minCost){
            minCost=currentCost;
            for (int i = 0; i < numCities; i++)
            {
                optimalPath[i]=path[i];
            }
            
        }
    }else{
        for (int i = depth; i < numCities; i++)
        {
            temp=path[depth];
            path[depth]=path[i];
            path[i]=temp;

            permute(path,depth+1);

            temp=path[depth];
            path[depth]=path[i];
            path[i]=temp;
        }
        
    }
}

int main()
{

printf("Enter the number of cities : ");


 int i, j;

    printf("Enter the number of cities: ");
    scanf("%d", &numCities);

    printf("Enter the cost matrix:\n");
    for (i = 0; i < numCities; i++) {
        for (j = 0; j < numCities; j++) {
            scanf("%d", &cost[i][j]);
        }
    }


int path[MAX];
for (int i = 0; i < numCities; i++)
{
   path[i]=i;
   visited[i]=0;
}

permute(path,0);

printf("Print the optimal Path ");
for (int i = 0; i < numCities; i++)
{
    printf("%d ",optimalPath[i]);

}
printf("%d",optimalPath[0]);

printf("\n Minimum Cost : %d\n",minCost);



    return 0;
}