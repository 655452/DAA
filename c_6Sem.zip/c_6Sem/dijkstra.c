#include<stdio.h>
#include<limits.h>
#include <stdbool.h>
#define V 4

int minDistance(int dist[],bool spSet[]){
    int min=INT_MAX,min_index;
    for (int i = 0; i < V; i++)
    {
        if(spSet[i]==false&&dist[i]<=min){
            min=dist[i],min_index=i;
        }
    }
    
return min_index;
}

// print array
void print(int dist[]){
printf("\nVertex from -> source \n");
    for (int i = 0; i < V; i++)
    {
        printf("%d -> %d \n",i,dist[i]);
    }
    
}

void dijkstra(int graph[V][V],int src){

int dist[V];

bool spSet[V];

for (int i = 0; i < V; i++)
{
    dist[i]=INT_MAX,spSet[i]=false;
}


dist[src]=0;
print(dist);

for (int count = 0; count < V-1; count++)
{
    int u=minDistance(dist,spSet);
    spSet[u]=true;
    for(int v=0;v<V;v++){
        if(!spSet[v]&&graph[u][v]&&dist[u]!=INT_MAX&&dist[u]+graph[u][v]<dist[v]){
            dist[v]=dist[u]+graph[u][v];
        }
    }
}

print(dist);

}




int main()
{
     int graph[V][V] = { {1,2,3,5},
                        {2,4,3,6},
                        {2,0,0,7},
                        {1,4,5,0} };
  dijkstra(graph,0);

    return 0;
}