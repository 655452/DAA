#include<conio.h>
#include<stdio.h>

#define MAX 100

void bsf(int adj[][MAX],int visited[],int start,int n){

int queue[MAX],front=-1,rear=-1,i;
// enqueing teh strt vertex in queue
queue[++rear]=start;
visited[start]=1;


while(front!=rear){

    start=queue[++front];
    printf("%d",start);
    for(i=0;i<n;i++){
        if(adj[start][i]&&!visited[i]){
            queue[++rear]=i;
            visited[i]=1;

        }
    }
}


}

int main(){

    int adj[MAX][MAX],visited[MAX]={0};
    int i,j,n;
    printf("Entert the number of vertices : ");
    scanf("%d",&n);

    printf("Enter the adjacency matrix :\n");
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d",&adj[i][j]);
        }
        
    }

    printf("Bsf Traversall starting from vertex 0 ;");
    bsf(adj,visited,0,n);
    return 0;
}